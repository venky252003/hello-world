# HtmlWebpackPlugin and Output into Parent Directory #hwp

Test case for issue #15
