# Dashes in Chunk Names

Test case for issue #53
