# Plugin Order: first uglify.js, then SRI

Simple test case to ensure plugin order doesn't matter. See also
example `plugin-order-sri-uglify`.
