# Plugin Order: first SRI, then uglify.js

Simple test case to ensure plugin order doesn't matter. See also
example `plugin-order-uglify-sri`.
