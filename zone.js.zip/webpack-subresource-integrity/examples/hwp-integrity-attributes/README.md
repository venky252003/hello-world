# HtmlWebpackPlugin Includes Integrity Attributes in Output #hwp

Test case for issue #5
