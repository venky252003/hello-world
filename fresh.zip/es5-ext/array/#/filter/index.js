"use strict";

module.exports = require("./is-implemented")()
		? Array.prototype.filter : require("./shim");
