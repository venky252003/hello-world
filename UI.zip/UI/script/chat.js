'use strict'

function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function GetTime(){
        var d = new Date();
        var h = addZero(d.getHours());
        var m = addZero(d.getMinutes());
        var s = addZero(d.getSeconds());
        var time = h + ":" + m + ":" + s;
    return time;
}

$(document).ready(function(){
    
    var hello = { "msg" : "Welcome to BDA Chat bot, what help i can do?", "time" : GetTime() };
    $("#incoming").template("incoming");
    $.tmpl("incoming", hello).appendTo('#msg_history');

    $('#btnSend').click(function(){      
        var url = "" + $('#txtMessage').val()

        $.ajax({
            url: url,
            type: 'GET',
            data: '',
            success: function(data) {
                hello.msg = data;
                hello.time = GetTime();                  
                $("#outgoing").template("outgoing");
                $.tmpl("outgoing", hello).appendTo('#msg_history');
                $('#txtMessage').val('');
            },
            error: function(e) {
              //called when there is an error
              console.log(e.message);
            }
          });
    })
});

