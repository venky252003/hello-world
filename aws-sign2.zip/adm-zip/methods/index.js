exports.Deflater = require("./deflater");
exports.Inflater = require("./inflater");