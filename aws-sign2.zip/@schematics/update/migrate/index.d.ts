import { Rule } from '@angular-devkit/schematics';
import { PostUpdateSchema } from './schema';
export default function (options: PostUpdateSchema): Rule;
