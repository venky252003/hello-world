import { Rule } from '@angular-devkit/schematics';
import { Schema as DirectiveOptions } from './schema';
export default function (options: DirectiveOptions): Rule;
