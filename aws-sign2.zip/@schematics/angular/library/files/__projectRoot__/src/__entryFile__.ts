/*
 * Public API Surface of <%= dasherize(name) %>
 */

export * from './lib/<%= dasherize(name) %>.service';
export * from './lib/<%= dasherize(name) %>.component';
export * from './lib/<%= dasherize(name) %>.module';
