import { Rule } from '@angular-devkit/schematics';
import { Schema as GuardOptions } from './schema';
export default function (options: GuardOptions): Rule;
