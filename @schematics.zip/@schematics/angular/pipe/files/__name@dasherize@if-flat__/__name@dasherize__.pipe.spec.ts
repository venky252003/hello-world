import { <%= classify(name) %>Pipe } from './<%= dasherize(name) %>.pipe';

describe('<%= classify(name) %>Pipe', () => {
  it('create an instance', () => {
    const pipe = new <%= classify(name) %>Pipe();
    expect(pipe).toBeTruthy();
  });
});
