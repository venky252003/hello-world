export enum <%= classify(name) %> {
}
