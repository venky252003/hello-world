import { loader } from 'webpack';
export declare function ngcLoader(this: loader.LoaderContext): void;
