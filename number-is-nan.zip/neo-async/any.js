'use stirct';

module.exports = require('./async').any;
