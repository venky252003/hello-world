'use stirct';

module.exports = require('./async').sortBySeries;
