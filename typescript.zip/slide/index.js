module.exports=require("./lib/slide")
