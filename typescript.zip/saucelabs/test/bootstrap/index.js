// Chai
global.chai   = require('chai');
global.should = global.chai.should();

// Helpers
global.chai.use(require('../helpers/'));
