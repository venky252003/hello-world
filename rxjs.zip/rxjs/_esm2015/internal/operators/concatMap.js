import { mergeMap } from './mergeMap';
export function concatMap(project, resultSelector) {
    return mergeMap(project, resultSelector, 1);
}
//# sourceMappingURL=concatMap.js.map