/// <amd-module name="@angular/common/locales/am" />
declare const _default: (string | number | (string[] | undefined)[] | number[] | (string | undefined)[] | ((n: number) => number) | {
    'AUD': string[];
    'CNH': string[];
    'ETB': string[];
    'JPY': string[];
    'THB': string[];
    'TWD': string[];
    'USD': string[];
} | undefined)[];
export default _default;
