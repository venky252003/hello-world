/// <amd-module name="@angular/common/locales/agq" />
declare const _default: (string | number | (string[] | undefined)[] | number[] | (string | undefined)[] | ((n: number) => number) | {
    'JPY': string[];
    'USD': string[];
} | undefined)[];
export default _default;
