/// <amd-module name="@angular/common/locales/af-NA" />
declare const _default: (string | number | (string[] | undefined)[] | number[] | (string | undefined)[] | ((n: number) => number) | {
    'JPY': string[];
    'MXN': (string | undefined)[];
    'NAD': string[];
    'RON': (string | undefined)[];
    'THB': string[];
    'TWD': string[];
    'USD': string[];
    'ZAR': string[];
} | undefined)[];
export default _default;
