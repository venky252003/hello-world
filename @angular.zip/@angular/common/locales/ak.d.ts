/// <amd-module name="@angular/common/locales/ak" />
declare const _default: (string | number | (string[] | undefined)[] | number[] | (string | undefined)[] | ((n: number) => number) | {
    'GHS': string[];
    'JPY': string[];
    'USD': string[];
} | undefined)[];
export default _default;
