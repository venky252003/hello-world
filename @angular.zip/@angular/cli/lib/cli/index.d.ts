export default function (options: any): Promise<number>;
