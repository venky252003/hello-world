export declare function findUp(names: string | string[], from: string): string;
